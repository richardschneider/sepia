﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security;

[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("Mvp.Xml")]
[assembly: AssemblyDescription("MVP XML Library")]
[assembly: AssemblyVersion("2.0.*")]

[assembly: AllowPartiallyTrustedCallers]