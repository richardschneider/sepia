using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Permissions;

[assembly: ComVisible(false)]
[assembly: CLSCompliant(true)]

[assembly: AssemblyTitle("Mvp.Xml.XInclude")]
[assembly: AssemblyDescription("MVP XML Library - XInclude.NET Module")]
[assembly: AssemblyVersion("2.0.*")]

#region Security Permissions

//[assembly: SecurityPermission(SecurityAction.RequestRefuse, UnmanagedCode=true)]

#endregion Security Permissions
