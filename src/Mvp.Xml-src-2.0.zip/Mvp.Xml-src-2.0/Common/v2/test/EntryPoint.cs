using System;
using System.Collections.Generic;
using System.Text;
using Mvp.Xml.Tests.XslReaderTests;

namespace Mvp.Xml.Tests.Common
{
    class EntryPoint
    {
        static void Main(string[] args)
        {
            //XslReaderTests.XslReaderTests t = new XslReaderTests.XslReaderTests();
            //t.Test5();
            MvpXslTransformTests t = new MvpXslTransformTests();
            t.ResolverTestIXPathNavigableInput();
        }
    }
}
